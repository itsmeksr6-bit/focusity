interface Props {
  /** Base font size is inherited: size via text-* classes, e.g. `text-[30px]`. */
  className?: string;
  /** Use on dark grounds: letters render white so the rings stay the gradient moment. */
  onDark?: boolean;
}

function BullseyeMark({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="focusity-ring" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#2b2fa6" />
          <stop offset="0.55" stopColor="#2e77d2" />
          <stop offset="1" stopColor="#17c1d8" />
        </linearGradient>
      </defs>
      <circle cx="20" cy="20" r="15.5" fill="none" stroke="url(#focusity-ring)" strokeWidth="7" />
      <circle cx="20" cy="20" r="6.5" fill="none" stroke="url(#focusity-ring)" strokeWidth="5" />
      <circle cx="20" cy="20" r="2.4" fill="url(#focusity-ring)" />
    </svg>
  );
}

export default function FocusityLogo({ className = '', onDark = false }: Props) {
  return (
    <span
      className={`inline-flex items-center font-bold leading-none tracking-tight ${className}`}
    >
      <span className={onDark ? 'text-white' : 'text-brand-indigo'}>F</span>
      <BullseyeMark className="mx-[0.08em] h-[0.78em] w-[0.78em] self-center translate-y-[0.04em]" />
      <span
        className={`bg-clip-text text-transparent ${
          onDark
            ? 'bg-linear-to-r from-white via-white to-brand-cyan'
            : 'bg-linear-to-r from-brand-indigo via-brand-blue to-[#0e93a6]'
        }`}
      >
        cusity
      </span>
    </span>
  );
}
