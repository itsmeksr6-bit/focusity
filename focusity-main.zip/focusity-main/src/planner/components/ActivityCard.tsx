import type { Activity } from '../types';
import {
  formatTime,
  getUrgencyLabel,
  TYPE_LABELS,
  PRIORITY_TEXT,
  PRIORITY_DOT,
} from '../lib/utils';

interface Props {
  activity: Activity;
  onToggle: (id: string) => void;
  onToggleSubtask?: (activityId: string, subtaskId: string) => void;
  onDelete?: (id: string) => void;
}

export default function ActivityCard({
  activity,
  onToggle,
  onToggleSubtask,
  onDelete,
}: Props) {
  const isDone = activity.status === 'completed' || activity.status === 'submitted';
  const urgency = getUrgencyLabel(activity.deadline);
  const isOverdue = urgency === 'Overdue';
  const isUrgent = isOverdue || urgency === 'Due today' || urgency === 'Due tomorrow';

  return (
    <div className="group relative border-b border-soft-mist px-6 py-4 transition-colors last:border-b-0 hover:bg-warm-parchment/60">
      <div className="flex items-start gap-4">
        <button
          onClick={() => onToggle(activity.id)}
          aria-label={isDone ? 'Mark as not done' : 'Mark as done'}
          className={`mt-1 flex h-[18px] w-[18px] shrink-0 items-center justify-center rounded-full border transition-colors ${
            isDone
              ? 'border-brand-indigo bg-linear-to-br from-brand-indigo to-brand-blue text-white'
              : 'border-stone-gray/60 hover:border-brand-indigo'
          }`}
        >
          {isDone && (
            <svg className="h-2.5 w-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
            </svg>
          )}
        </button>

        <div className="min-w-0 flex-1">
          <p
            className={`text-[15px] leading-snug font-[460] ${
              isDone ? 'text-stone-gray line-through' : 'text-ink-charcoal'
            }`}
          >
            {activity.title}
          </p>
          {activity.subject && (
            <p className="mt-0.5 text-[13px] text-stone-gray">{activity.subject}</p>
          )}

          <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px]">
            <span className="text-[13px] text-stone-gray">
              {TYPE_LABELS[activity.type]}
            </span>
            {activity.startTime && (
              <span className="text-stone-gray tabular-nums">
                {formatTime(activity.startTime)}
                {activity.endTime ? ` – ${formatTime(activity.endTime)}` : ''}
              </span>
            )}
            {activity.deadline && (
              <span
                className={
                  isOverdue
                    ? 'font-medium text-brand-indigo'
                    : isUrgent
                      ? 'font-medium text-ink-charcoal'
                      : 'text-stone-gray'
                }
              >
                {urgency}
              </span>
            )}
            {activity.estimatedMinutes && (
              <span className="text-stone-gray tabular-nums">
                {activity.estimatedMinutes} min
              </span>
            )}
            <span
              className={`inline-flex items-center gap-1.5 capitalize ${PRIORITY_TEXT[activity.priority]}`}
            >
              <span className={`h-1 w-1 rounded-full ${PRIORITY_DOT[activity.priority]}`} />
              {activity.priority}
            </span>
          </div>

          {activity.subtasks && activity.subtasks.length > 0 && (
            <div className="mt-3 space-y-1.5 border-t border-soft-mist pt-3">
              {activity.subtasks.map((st) => (
                <label key={st.id} className="flex cursor-pointer items-center gap-2.5 text-[13px]">
                  <input
                    type="checkbox"
                    checked={st.completed}
                    onChange={() => onToggleSubtask?.(activity.id, st.id)}
                    className="h-3.5 w-3.5 rounded-[3px] border-stone-gray/60 accent-[#2b2fa6]"
                  />
                  <span className={st.completed ? 'text-stone-gray line-through' : 'text-ink-charcoal'}>
                    {st.title}
                  </span>
                </label>
              ))}
            </div>
          )}
        </div>

        {onDelete && (
          <button
            onClick={() => onDelete(activity.id)}
            className="rounded-md p-1 text-stone-gray/0 transition-colors hover:text-ink-charcoal group-hover:text-stone-gray"
            title="Delete"
            aria-label="Delete activity"
          >
            <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        )}
      </div>
    </div>
  );
}
