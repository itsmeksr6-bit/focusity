import { useEffect, useRef, useState } from 'react';
import type { Activity } from '../types';

interface Props {
  activities: Activity[];
  onComplete: (activityId: string, minutes: number) => void;
  /** Reports whether a session is currently holding the focus lock. */
  onActiveChange?: (active: boolean) => void;
}

async function enterFullscreen() {
  try {
    await document.documentElement.requestFullscreen();
  } catch {
    // Fullscreen is a nicety; the session still runs without it.
  }
}

function exitFullscreen() {
  if (document.fullscreenElement) {
    document.exitFullscreen().catch(() => {});
  }
}

/* ---------- Alarm ---------- */

function createAlarm() {
  const AudioCtor =
    window.AudioContext ??
    (window as unknown as { webkitAudioContext?: typeof AudioContext })
      .webkitAudioContext;
  const ctx = new AudioCtor();

  const beep = () => {
    if (ctx.state === 'suspended') void ctx.resume().catch(() => {});
    const t = ctx.currentTime;
    [880, 660, 880].forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(freq, t + i * 0.16);
      gain.gain.setValueAtTime(0.0001, t + i * 0.16);
      gain.gain.exponentialRampToValueAtTime(0.18, t + i * 0.16 + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, t + i * 0.16 + 0.14);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t + i * 0.16);
      osc.stop(t + i * 0.16 + 0.18);
    });
    navigator.vibrate?.(180);
  };

  let timer: number | null = null;

  return {
    ctx,
    start() {
      beep();
      if (timer === null) {
        timer = window.setInterval(beep, 1100);
      }
    },
    stop() {
      if (timer !== null) {
        clearInterval(timer);
        timer = null;
      }
      void ctx.suspend().catch(() => {});
    },
  };
}

let alarm: ReturnType<typeof createAlarm> | null = null;
let originalTitle = '';

function startAlarm() {
  if (!alarm) alarm = createAlarm();
  if (originalTitle === '') originalTitle = document.title;
  document.title = '⏰ Return to Focusity!';
  if (alarm.ctx.state === 'suspended') {
    void alarm.ctx.resume().catch(() => {});
  }
  alarm.start();
}

function stopAlarm() {
  if (alarm) alarm.stop();
  if (originalTitle !== '') {
    document.title = originalTitle;
    originalTitle = '';
  }
}

/* ---------- Component ---------- */

export default function FocusMode({ activities, onComplete, onActiveChange }: Props) {
  const openTasks = activities.filter(
    (a) =>
      (a.type === 'assignment' || a.type === 'study' || a.type === 'personal') &&
      a.status !== 'completed' &&
      a.status !== 'submitted'
  );

  const [selectedId, setSelectedId] = useState<string>(openTasks[0]?.id || '');
  const [minutes, setMinutes] = useState(25);
  const [secondsLeft, setSecondsLeft] = useState(25 * 60);
  const [running, setRunning] = useState(false);
  const [sessionStarted, setSessionStarted] = useState(false);
  const [locked, setLocked] = useState(false);
  const [distractions, setDistractions] = useState(0);
  const intervalRef = useRef<number | null>(null);
  const interruptedRef = useRef(false);

  const selected = activities.find((a) => a.id === selectedId);

  useEffect(() => {
    onActiveChange?.(running);
  }, [running, onActiveChange]);

  useEffect(() => {
    if (running) {
      intervalRef.current = window.setInterval(() => {
        setSecondsLeft((s) => {
          if (s <= 1) {
            setRunning(false);
            exitFullscreen();
            if (selectedId) onComplete(selectedId, minutes);
            return 0;
          }
          return s - 1;
        });
      }, 1000);
    } else if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running, selectedId, minutes, onComplete]);

  /** While the session runs, leaving the page (tab switch, minimize, window
   *  blur) or leaving fullscreen pauses the timer, locks the screen and sounds
   *  the alarm until the user returns and resumes. */
  useEffect(() => {
    if (!running) return;

    const interrupt = () => {
      // Tab-hide, fullscreen-exit and window blur can all fire for one
      // interruption — ring the alarm only once.
      if (interruptedRef.current) return;
      interruptedRef.current = true;
      setRunning(false);
      setLocked(true);
      setDistractions((d) => d + 1);
      startAlarm();
    };

    const onVisibility = () => {
      if (document.hidden) interrupt();
    };
    const onFullscreenChange = () => {
      if (!document.fullscreenElement) interrupt();
    };
    const onBlur = () => {
      if (!document.hasFocus()) interrupt();
    };

    document.addEventListener('visibilitychange', onVisibility);
    document.addEventListener('fullscreenchange', onFullscreenChange);
    window.addEventListener('blur', onBlur);
    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      document.removeEventListener('fullscreenchange', onFullscreenChange);
      window.removeEventListener('blur', onBlur);
    };
  }, [running]);

  // Leaving the screen without ending the session must not leave an alarm ringing.
  useEffect(() => () => stopAlarm(), []);

  const start = () => {
    if (!selectedId) return;
    interruptedRef.current = false;
    stopAlarm();
    setSecondsLeft(minutes * 60);
    setRunning(true);
    setSessionStarted(true);
    setDistractions(0);
    void enterFullscreen();
  };

  const pause = () => {
    setRunning(false);
    stopAlarm();
    exitFullscreen();
  };

  const reset = () => {
    setRunning(false);
    stopAlarm();
    exitFullscreen();
    setLocked(false);
    setSecondsLeft(minutes * 60);
    setSessionStarted(false);
    setDistractions(0);
  };

  const resume = () => {
    interruptedRef.current = false;
    stopAlarm();
    setLocked(false);
    void enterFullscreen();
    setRunning(true);
  };

  const mins = Math.floor(secondsLeft / 60);
  const secs = secondsLeft % 60;

  return (
    <div className="mx-auto max-w-lg space-y-10">
      <div>
        <h1 className="text-[28px] font-[460] leading-[1.14] tracking-[-0.022em] text-ink-charcoal">
          Focus Mode
        </h1>
        <p className="mt-1.5 text-sm font-[460] leading-[1.5] text-stone-gray">
          Turn a planned activity into real work time — leaving the focus screen
          sounds an alarm until you come back
        </p>
      </div>

      <div>
        <label className="mb-2 block text-sm font-bold text-ink-charcoal">
          What are you working on?
        </label>
        <select
          value={selectedId}
          onChange={(e) => {
            setSelectedId(e.target.value);
            reset();
          }}
          disabled={sessionStarted}
          className="w-full rounded-lg border border-soft-mist bg-paper-white px-3.5 py-2.5 text-[15px] font-[460] text-ink-charcoal outline-none transition-colors focus:border-brand-blue disabled:opacity-50"
        >
          {openTasks.length === 0 && <option value="">No open tasks</option>}
          {openTasks.map((a) => (
            <option key={a.id} value={a.id}>
              {a.title} {a.subject ? `(${a.subject})` : ''}
            </option>
          ))}
        </select>
      </div>

      {!sessionStarted && (
        <div>
          <label className="mb-3 block text-sm font-bold text-ink-charcoal">Session length</label>
          <div className="flex flex-wrap gap-2">
            {[15, 25, 45, 60, 90].map((m) => (
              <button
                key={m}
                onClick={() => {
                  setMinutes(m);
                  setSecondsLeft(m * 60);
                }}
                className={`rounded-lg border px-4 py-2 text-[15px] font-[460] tabular-nums transition-colors ${
                  minutes === m
                    ? 'border-ink-charcoal bg-brand-tint text-ink-charcoal'
                    : 'border-soft-mist bg-paper-white text-stone-gray hover:border-ink-charcoal/40 hover:text-ink-charcoal'
                }`}
              >
                {m} min
              </button>
            ))}
          </div>
        </div>
      )}

      <div className="flex flex-col items-center rounded-2xl bg-brand-night px-8 py-14 text-white">
        {selected && (
          <p className="mb-6 max-w-xs text-center text-sm font-[460] leading-[1.5] text-white/80">
            {selected.title}
          </p>
        )}
        <div className="font-mono text-6xl font-medium tracking-tight tabular-nums">
          {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}
        </div>
        <p className="mt-4 text-sm font-[460] text-white/80">
          {running ? 'Focusing — other pages locked' : sessionStarted ? 'Paused' : 'Ready'}
        </p>
        {sessionStarted && distractions > 0 && (
          <p className="mt-1 text-[13px] font-[460] text-white/75">
            {distractions} distraction{distractions === 1 ? '' : 's'} logged
          </p>
        )}
      </div>

      <div className="flex justify-center gap-3">
        {!running ? (
          <button
            onClick={start}
            disabled={!selectedId}
            className="h-12 rounded-2xl bg-linear-to-r from-brand-indigo to-brand-blue px-8 text-[16px] font-[460] text-white transition-opacity hover:opacity-90 disabled:opacity-60"
          >
            {sessionStarted ? 'Restart' : 'Start Focus'}
          </button>
        ) : (
          <button
            onClick={pause}
            className="h-12 rounded-lg bg-brand-tint px-8 text-[16px] font-[460] text-ink-charcoal transition-opacity hover:opacity-90"
          >
            Pause
          </button>
        )}
        {sessionStarted && !running && !locked && (
          <button
            onClick={resume}
            className="h-12 rounded-2xl bg-linear-to-r from-brand-indigo to-brand-blue px-8 text-[16px] font-[460] text-white transition-opacity hover:opacity-90 disabled:opacity-60"
          >
            Resume
          </button>
        )}
        {sessionStarted && (
          <button
            onClick={reset}
            className="h-12 rounded-lg border border-soft-mist bg-paper-white px-6 text-[16px] font-[460] text-stone-gray transition-colors hover:border-ink-charcoal hover:text-ink-charcoal"
          >
            Reset
          </button>
        )}
      </div>

      <p className="text-center text-sm font-[460] leading-[1.5] text-stone-gray">
        When the timer ends, the activity is marked complete and time is recorded.
        Switching tabs or apps during a session pauses the work, rings an alarm
        and locks Focusity until you resume. Fully closing the tab stops the sound
        — nothing else on your computer can be blocked by a website.
      </p>

      {/* Focus lock — covers the entire app until the user resumes */}
      {locked && (
        <div className="fixed inset-0 z-[60] flex flex-col items-center justify-center bg-brand-night px-6 text-center text-white">
          <Bullseye className="h-16 w-16" />
          <h2 className="mt-8 text-[49px] font-[460] leading-[1.2] tracking-[-0.027em]">
            You stepped away
          </h2>
          <p className="mt-4 max-w-md text-[16px] font-[460] leading-[1.5] text-white/85">
            Your focus session is paused and the rest of Focusity is locked while
            the alarm sounds.
            {distractions > 1 && ` That's ${distractions} interruptions so far.`}
          </p>
          <button
            onClick={resume}
            className="mt-10 h-12 rounded-2xl bg-white px-8 text-[16px] font-[460] text-ink-charcoal transition-opacity hover:opacity-90"
          >
            Resume focus
          </button>
          <button
            onClick={reset}
            className="mt-4 rounded-lg border border-white/60 px-5 py-2 text-[16px] font-[460] text-white transition-colors hover:bg-white/10"
          >
            End session
          </button>
        </div>
      )}
    </div>
  );
}

function Bullseye({ className = '' }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden="true">
      <circle cx="20" cy="20" r="15.5" fill="none" stroke="#17c1d8" strokeWidth="7" />
      <circle cx="20" cy="20" r="6.5" fill="none" stroke="#2e77d2" strokeWidth="5" />
      <circle cx="20" cy="20" r="2.4" fill="#ffffff" />
    </svg>
  );
}
