import type { Activity } from '../types';
import { getTodayActivities, getCompletionStats, formatDate } from '../lib/utils';
import ActivityCard from './ActivityCard';

interface Props {
  activities: Activity[];
  onToggle: (id: string) => void;
  onToggleSubtask: (activityId: string, subtaskId: string) => void;
  onDelete: (id: string) => void;
  onOpenAdd: () => void;
}

export default function MyDay({
  activities,
  onToggle,
  onToggleSubtask,
  onDelete,
  onOpenAdd,
}: Props) {
  const todayItems = getTodayActivities(activities);
  const stats = getCompletionStats(activities);
  const now = new Date();

  const scheduled = todayItems.filter((a) => a.startTime);
  const openTasks = todayItems.filter((a) => !a.startTime);

  return (
    <div className="space-y-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-bold text-brand-indigo">
            {formatDate(now.toISOString())}
          </p>
          <h1 className="mt-1 text-[28px] font-[460] leading-[1.14] tracking-[-0.022em] text-ink-charcoal">
            My Day
          </h1>
          <p className="mt-1.5 text-sm font-[460] leading-[1.5] text-stone-gray">
            {todayItems.length} items · {stats.percent}% of tracked work done
          </p>
        </div>
        <button
          onClick={onOpenAdd}
          className="flex h-11 items-center gap-2 rounded-2xl bg-linear-to-r from-brand-indigo to-brand-blue px-5 text-[16px] font-[460] text-white transition-opacity hover:opacity-90"
        >
          <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
          </svg>
          Quick Add
        </button>
      </div>

      <div className="rounded-2xl border border-soft-mist bg-paper-white p-6">
        <div className="flex items-baseline justify-between text-[15px] font-[460]">
          <span className="text-ink-charcoal">Today's progress</span>
          <span className="font-medium text-brand-indigo tabular-nums">{stats.percent}%</span>
        </div>
        <div className="mt-3 h-[4px] w-full overflow-hidden rounded-full bg-soft-mist">
          <div
            className="h-full rounded-full bg-linear-to-r from-brand-indigo to-brand-blue transition-all duration-500"
            style={{ width: `${stats.percent}%` }}
          />
        </div>
        <p className="mt-3 text-sm font-[460] leading-[1.5] text-stone-gray">
          {stats.done} of {stats.total} assignments &amp; goals completed
        </p>
      </div>

      {scheduled.length > 0 && (
        <section>
          <h2 className="mb-3 text-sm font-bold text-ink-charcoal">Timeline</h2>
          <div className="overflow-hidden rounded-2xl border border-soft-mist bg-paper-white">
            {scheduled.map((a) => (
              <ActivityCard
                key={a.id}
                activity={a}
                onToggle={onToggle}
                onToggleSubtask={onToggleSubtask}
                onDelete={onDelete}
              />
            ))}
          </div>
        </section>
      )}

      {openTasks.length > 0 && (
        <section>
          <h2 className="mb-3 text-sm font-bold text-ink-charcoal">Priorities &amp; Deadlines</h2>
          <div className="overflow-hidden rounded-2xl border border-soft-mist bg-paper-white">
            {openTasks.map((a) => (
              <ActivityCard
                key={a.id}
                activity={a}
                onToggle={onToggle}
                onToggleSubtask={onToggleSubtask}
                onDelete={onDelete}
              />
            ))}
          </div>
        </section>
      )}

      {todayItems.length === 0 && (
        <div className="rounded-2xl border border-dashed border-soft-mist bg-paper-white py-20 text-center">
          <p className="text-[16px] font-[460] text-ink-charcoal">Nothing scheduled today</p>
          <p className="mt-1 text-sm font-[460] leading-[1.5] text-stone-gray">
            Add a class, assignment or study session
          </p>
          <button
            onClick={onOpenAdd}
            className="mt-6 h-11 rounded-2xl bg-linear-to-r from-brand-indigo to-brand-blue px-5 text-[16px] font-[460] text-white transition-opacity hover:opacity-90"
          >
            Add Activity
          </button>
        </div>
      )}
    </div>
  );
}
