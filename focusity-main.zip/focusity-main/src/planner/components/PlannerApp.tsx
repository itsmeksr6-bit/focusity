import { useState } from 'react';
import { useActivities } from '../hooks/useActivities';
import { useAuth } from '@/hooks/use-auth';
import FocusityLogo from '@/components/FocusityLogo';
import MyDay from './MyDay';
import Assignments from './Assignments';
import FocusMode from './FocusMode';
import QuickAdd from './QuickAdd';
import ActivityCard from './ActivityCard';

type Tab = 'myday' | 'assignments' | 'focus' | 'all';

const TABS: { id: Tab; label: string }[] = [
  { id: 'myday', label: 'My Day' },
  { id: 'assignments', label: 'Assignments' },
  { id: 'focus', label: 'Focus' },
  { id: 'all', label: 'All' },
];

export default function PlannerApp() {
  const {
    activities,
    addActivity,
    updateActivity,
    deleteActivity,
    toggleStatus,
    toggleSubtask,
  } = useActivities();
  const { signOut } = useAuth();

  const [tab, setTab] = useState<Tab>('myday');
  const [showAdd, setShowAdd] = useState(false);
  const [focusActive, setFocusActive] = useState(false);

  const handleFocusComplete = (activityId: string, minutes: number) => {
    updateActivity(activityId, {
      status: 'completed',
      actualMinutes: minutes,
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 border-b border-soft-mist bg-warm-parchment/80 backdrop-blur-[12px]">
        <div className="mx-auto flex max-w-[1200px] items-center justify-between px-6 py-4">
          <div className="flex items-center gap-3">
            <FocusityLogo className="text-[19px]" />
          </div>
          <div className="flex items-center gap-6">
            <button
              onClick={() => void signOut()}
              className="text-[15px] font-[460] text-ink-charcoal transition-colors hover:text-stone-gray"
            >
              Log out
            </button>
            <button
              onClick={() => setShowAdd(true)}
              disabled={focusActive}
              title={focusActive ? 'Locked during a focus session' : undefined}
              className="flex h-10 items-center gap-2 rounded-lg bg-linear-to-r from-brand-indigo to-brand-blue px-4 text-[16px] font-[460] text-white transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
              </svg>
              Quick Add
            </button>
          </div>
        </div>

        <nav className="mx-auto max-w-[1200px] px-6 pb-4">
          <div className="inline-flex rounded-lg border border-soft-mist bg-paper-white p-1">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                disabled={focusActive && t.id !== 'focus'}
                title={
                  focusActive && t.id !== 'focus'
                    ? 'Locked during a focus session'
                    : undefined
                }
                className={`px-4 py-2 text-[16px] font-[460] transition-colors disabled:cursor-not-allowed disabled:opacity-60 ${
                  tab === t.id
                    ? 'bg-brand-tint text-ink-charcoal'
                    : 'bg-paper-white text-stone-gray hover:text-ink-charcoal'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
          {focusActive && (
            <span className="ml-3 inline-flex items-center gap-2 rounded-full bg-brand-tint px-3 py-1 text-[13px] font-[460] text-ink-charcoal">
              <span className="h-1.5 w-1.5 rounded-full bg-brand-blue" />
              Focus in progress — tabs locked
            </span>
          )}
        </nav>
      </header>

      <main className="mx-auto max-w-3xl px-6 py-10">
        {tab === 'myday' && (
          <MyDay
            activities={activities}
            onToggle={toggleStatus}
            onToggleSubtask={toggleSubtask}
            onDelete={deleteActivity}
            onOpenAdd={() => setShowAdd(true)}
          />
        )}
        {tab === 'assignments' && (
          <Assignments
            activities={activities}
            onToggle={toggleStatus}
            onToggleSubtask={toggleSubtask}
            onDelete={deleteActivity}
            onOpenAdd={() => setShowAdd(true)}
          />
        )}
        {tab === 'focus' && (
          <FocusMode
            activities={activities}
            onComplete={handleFocusComplete}
            onActiveChange={setFocusActive}
          />
        )}
        {tab === 'all' && (
          <div>
            <div className="mb-8">
              <h1 className="text-[28px] font-[460] leading-[1.14] tracking-[-0.022em] text-ink-charcoal">
                All Activities
              </h1>
              <p className="mt-1.5 text-sm font-[460] leading-[1.5] text-stone-gray">
                {activities.length} total records
              </p>
            </div>
            {activities.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-soft-mist bg-paper-white py-20 text-center">
                <p className="text-sm font-[460] text-stone-gray">No activities yet.</p>
              </div>
            ) : (
              <div className="overflow-hidden rounded-2xl border border-soft-mist bg-paper-white">
                {activities
                  .slice()
                  .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))
                  .map((a) => (
                    <ActivityCard
                      key={a.id}
                      activity={a}
                      onToggle={toggleStatus}
                      onDelete={deleteActivity}
                    />
                  ))}
              </div>
            )}
          </div>
        )}
      </main>

      {showAdd && (
        <QuickAdd onAdd={(data) => addActivity(data)} onClose={() => setShowAdd(false)} />
      )}
    </div>
  );
}
