import type { Activity } from '../types';
import ActivityCard from './ActivityCard';

interface Props {
  activities: Activity[];
  onToggle: (id: string) => void;
  onToggleSubtask: (activityId: string, subtaskId: string) => void;
  onDelete: (id: string) => void;
  onOpenAdd: () => void;
}

export default function Assignments({
  activities,
  onToggle,
  onToggleSubtask,
  onDelete,
  onOpenAdd,
}: Props) {
  const assignments = activities
    .filter((a) => a.type === 'assignment' || a.type === 'exam')
    .sort((a, b) => {
      const da = a.deadline ? new Date(a.deadline).getTime() : Infinity;
      const db = b.deadline ? new Date(b.deadline).getTime() : Infinity;
      return da - db;
    });

  const open = assignments.filter((a) => a.status !== 'completed' && a.status !== 'submitted');
  const done = assignments.filter((a) => a.status === 'completed' || a.status === 'submitted');

  return (
    <div className="space-y-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-[28px] font-[460] leading-[1.14] tracking-[-0.022em] text-ink-charcoal">
            Assignments &amp; Exams
          </h1>
          <p className="mt-1.5 text-sm font-[460] leading-[1.5] text-stone-gray">
            {open.length} open · {done.length} completed
          </p>
        </div>
        <button
          onClick={onOpenAdd}
          className="h-11 rounded-2xl bg-linear-to-r from-brand-indigo to-brand-blue px-5 text-[16px] font-[460] text-white transition-opacity hover:opacity-90"
        >
          Add
        </button>
      </div>

      {open.length > 0 && (
        <section>
          <h2 className="mb-3 text-sm font-bold text-ink-charcoal">Upcoming</h2>
          <div className="overflow-hidden rounded-2xl border border-soft-mist bg-paper-white">
            {open.map((a) => (
              <ActivityCard
                key={a.id}
                activity={a}
                onToggle={onToggle}
                onToggleSubtask={onToggleSubtask}
                onDelete={onDelete}
              />
            ))}
          </div>
        </section>
      )}

      {done.length > 0 && (
        <section>
          <h2 className="mb-3 text-sm font-bold text-ink-charcoal">Completed</h2>
          <div className="overflow-hidden rounded-2xl border border-soft-mist bg-paper-white">
            {done.map((a) => (
              <ActivityCard
                key={a.id}
                activity={a}
                onToggle={onToggle}
                onToggleSubtask={onToggleSubtask}
                onDelete={onDelete}
              />
            ))}
          </div>
        </section>
      )}

      {assignments.length === 0 && (
        <div className="rounded-2xl border border-dashed border-soft-mist bg-paper-white py-20 text-center">
          <p className="text-[16px] font-[460] text-ink-charcoal">No assignments yet</p>
          <button
            onClick={onOpenAdd}
            className="mt-6 h-11 rounded-2xl bg-linear-to-r from-brand-indigo to-brand-blue px-5 text-[16px] font-[460] text-white transition-opacity hover:opacity-90"
          >
            Add your first assignment
          </button>
        </div>
      )}
    </div>
  );
}
