import { useState } from 'react';
import type { FormEvent } from 'react';
import type { Activity, ActivityType, Priority } from '../types';
import { TYPE_LABELS } from '../lib/utils';

interface Props {
  onAdd: (data: Omit<Activity, 'id' | 'createdAt' | 'updatedAt'>) => void;
  onClose: () => void;
}

const TYPES: ActivityType[] = ['assignment', 'exam', 'study', 'class', 'personal', 'reminder'];
const PRIORITIES: Priority[] = ['high', 'medium', 'low'];
const DURATIONS = [15, 25, 45, 60, 90, 120];

const inputClass =
  'w-full border-b border-soft-mist bg-transparent py-2.5 text-[15px] font-[460] text-ink-charcoal outline-none transition-colors placeholder:font-normal placeholder:text-stone-gray/70 focus:border-ink-charcoal';

export default function QuickAdd({ onAdd, onClose }: Props) {
  const [type, setType] = useState<ActivityType>('assignment');
  const [title, setTitle] = useState('');
  const [subject, setSubject] = useState('');
  const [deadline, setDeadline] = useState('');
  const [startTime, setStartTime] = useState('');
  const [endTime, setEndTime] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [estimatedMinutes, setEstimatedMinutes] = useState(45);
  const [reminderEnabled, setReminderEnabled] = useState(true);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    onAdd({
      type,
      title: title.trim(),
      subject: subject.trim() || undefined,
      deadline: deadline ? new Date(deadline).toISOString() : undefined,
      startTime: startTime ? new Date(startTime).toISOString() : undefined,
      endTime: endTime ? new Date(endTime).toISOString() : undefined,
      priority,
      status: 'not_started',
      estimatedMinutes,
      reminderEnabled,
      color: '#2b2fa6',
    });
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink-charcoal/30 p-4 backdrop-blur-[2px]"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-soft-mist bg-paper-white"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-soft-mist px-6 py-4">
          <h2 className="text-[19px] font-bold tracking-tight text-ink-charcoal">Add Activity</h2>
          <button
            onClick={onClose}
            aria-label="Close"
            className="p-1 text-stone-gray transition-colors hover:text-ink-charcoal"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 p-6">
          <div>
            <label className="mb-3 block text-sm font-bold text-ink-charcoal">Type</label>
            <div className="flex flex-wrap gap-2">
              {TYPES.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`rounded-lg border px-3 py-1.5 text-sm font-[460] transition-colors ${
                    type === t
                      ? 'border-ink-charcoal bg-brand-tint text-ink-charcoal'
                      : 'border-soft-mist bg-paper-white text-stone-gray hover:border-ink-charcoal/40 hover:text-ink-charcoal'
                  }`}
                >
                  {TYPE_LABELS[t]}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="mb-1 block text-sm font-bold text-ink-charcoal">Title</label>
            <input
              autoFocus
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Java Assignment – Core Questions"
              className={inputClass}
              required
            />
          </div>

          <div>
            <label className="mb-1 block text-sm font-bold text-ink-charcoal">Subject</label>
            <input
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="e.g. DBMS"
              className={inputClass}
            />
          </div>

          {(type === 'assignment' || type === 'exam' || type === 'reminder') && (
            <div>
              <label className="mb-1 block text-sm font-bold text-ink-charcoal">Deadline</label>
              <input
                type="datetime-local"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className={inputClass}
              />
            </div>
          )}

          {(type === 'class' || type === 'study' || type === 'personal') && (
            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="mb-1 block text-sm font-bold text-ink-charcoal">Start</label>
                <input
                  type="datetime-local"
                  value={startTime}
                  onChange={(e) => setStartTime(e.target.value)}
                  className={inputClass}
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-bold text-ink-charcoal">End</label>
                <input
                  type="datetime-local"
                  value={endTime}
                  onChange={(e) => setEndTime(e.target.value)}
                  className={inputClass}
                />
              </div>
            </div>
          )}

          <div>
            <label className="mb-3 block text-sm font-bold text-ink-charcoal">Estimated duration</label>
            <div className="flex flex-wrap gap-2">
              {DURATIONS.map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setEstimatedMinutes(m)}
                  className={`rounded-lg border px-3 py-1.5 text-sm font-[460] tabular-nums transition-colors ${
                    estimatedMinutes === m
                      ? 'border-ink-charcoal bg-brand-tint text-ink-charcoal'
                      : 'border-soft-mist bg-paper-white text-stone-gray hover:border-ink-charcoal/40 hover:text-ink-charcoal'
                  }`}
                >
                  {m < 60 ? `${m}m` : `${m / 60}h`}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="mb-3 block text-sm font-bold text-ink-charcoal">Priority</label>
            <div className="flex gap-2">
              {PRIORITIES.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPriority(p)}
                  className={`flex-1 rounded-lg border py-2 text-sm font-[460] capitalize transition-colors ${
                    priority === p
                      ? 'border-ink-charcoal bg-brand-tint text-ink-charcoal'
                      : 'border-soft-mist bg-paper-white text-stone-gray hover:border-ink-charcoal/40 hover:text-ink-charcoal'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <label className="flex cursor-pointer items-center gap-2.5 text-[15px] font-[460] text-ink-charcoal">
            <input
              type="checkbox"
              checked={reminderEnabled}
              onChange={(e) => setReminderEnabled(e.target.checked)}
              className="h-4 w-4 rounded-[4px] border-stone-gray/60 accent-[#2b2fa6]"
            />
            Enable reminder
          </label>

          <button
            type="submit"
            className="h-12 w-full rounded-2xl bg-linear-to-r from-brand-indigo to-brand-blue text-[16px] font-[460] text-white transition-opacity hover:opacity-90"
          >
            Add to Planner
          </button>
        </form>
      </div>
    </div>
  );
}
