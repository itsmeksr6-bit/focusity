import { useState, useEffect, useCallback } from 'react';
import type { Activity, ActivityStatus } from '../types';
import { loadActivities, saveActivities, generateId } from '../lib/storage';

export function useActivities() {
  // Lazily initialize from localStorage during first render, so there is no
  // mount effect that calls setState synchronously.
  const [activities, setActivities] = useState<Activity[]>(() => loadActivities());

  useEffect(() => {
    saveActivities(activities);
  }, [activities]);

  const addActivity = useCallback(
    (partial: Omit<Activity, 'id' | 'createdAt' | 'updatedAt'>) => {
      const now = new Date().toISOString();
      const newAct: Activity = {
        ...partial,
        id: generateId(),
        createdAt: now,
        updatedAt: now,
      };
      setActivities((prev) => [...prev, newAct]);
      return newAct;
    },
    []
  );

  const updateActivity = useCallback((id: string, updates: Partial<Activity>) => {
    setActivities((prev) =>
      prev.map((a) =>
        a.id === id ? { ...a, ...updates, updatedAt: new Date().toISOString() } : a
      )
    );
  }, []);

  const deleteActivity = useCallback((id: string) => {
    setActivities((prev) => prev.filter((a) => a.id !== id));
  }, []);

  const toggleStatus = useCallback((id: string) => {
    setActivities((prev) =>
      prev.map((a) => {
        if (a.id !== id) return a;
        const next: ActivityStatus =
          a.status === 'completed' || a.status === 'submitted'
            ? 'not_started'
            : a.type === 'assignment'
              ? 'submitted'
              : 'completed';
        return { ...a, status: next, updatedAt: new Date().toISOString() };
      })
    );
  }, []);

  const toggleSubtask = useCallback((activityId: string, subtaskId: string) => {
    setActivities((prev) =>
      prev.map((a) => {
        if (a.id !== activityId || !a.subtasks) return a;
        return {
          ...a,
          subtasks: a.subtasks.map((st) =>
            st.id === subtaskId ? { ...st, completed: !st.completed } : st
          ),
          updatedAt: new Date().toISOString(),
        };
      })
    );
  }, []);

  return {
    activities,
    addActivity,
    updateActivity,
    deleteActivity,
    toggleStatus,
    toggleSubtask,
  };
}
