import type { Activity, ActivityType, Priority } from '../types';

export function formatTime(iso?: string): string {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}

export function formatDate(iso?: string): string {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
}

export function formatDateTime(iso?: string): string {
  if (!iso) return '';
  return `${formatDate(iso)} ${formatTime(iso)}`;
}

export function isToday(iso?: string): boolean {
  if (!iso) return false;
  const d = new Date(iso);
  const today = new Date();
  return (
    d.getFullYear() === today.getFullYear() &&
    d.getMonth() === today.getMonth() &&
    d.getDate() === today.getDate()
  );
}

export function getDaysUntil(iso?: string): number | null {
  if (!iso) return null;
  const target = new Date(iso);
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export function getUrgencyLabel(deadline?: string): string {
  const days = getDaysUntil(deadline);
  if (days === null) return '';
  if (days < 0) return 'Overdue';
  if (days === 0) return 'Due today';
  if (days === 1) return 'Due tomorrow';
  return `Due in ${days} days`;
}

export const TYPE_LABELS: Record<ActivityType, string> = {
  class: 'Class',
  assignment: 'Assignment',
  exam: 'Exam',
  study: 'Study Session',
  reminder: 'Reminder',
  personal: 'Personal Goal',
};

/** Minimalism theme: priorities are communicated in near-monochrome. */
export const PRIORITY_TEXT: Record<Priority, string> = {
  high: 'text-foreground',
  medium: 'text-muted-foreground',
  low: 'text-muted-foreground/60',
};

export const PRIORITY_DOT: Record<Priority, string> = {
  high: 'bg-foreground',
  medium: 'bg-foreground/40',
  low: 'bg-foreground/20',
};

export function getTodayActivities(activities: Activity[]): Activity[] {
  return activities
    .filter((a) => {
      if (a.startTime && isToday(a.startTime)) return true;
      if (a.deadline && isToday(a.deadline)) return true;
      if (
        (a.type === 'assignment' || a.type === 'exam') &&
        a.status !== 'completed' &&
        a.status !== 'submitted' &&
        a.deadline
      ) {
        const days = getDaysUntil(a.deadline);
        return days !== null && days <= 3;
      }
      return false;
    })
    .sort((a, b) => {
      const tA = a.startTime || a.deadline || '';
      const tB = b.startTime || b.deadline || '';
      return tA.localeCompare(tB);
    });
}

export function getCompletionStats(activities: Activity[]) {
  const relevant = activities.filter(
    (a) => a.type === 'assignment' || a.type === 'study' || a.type === 'personal'
  );
  const total = relevant.length;
  const done = relevant.filter(
    (a) => a.status === 'completed' || a.status === 'submitted'
  ).length;
  const percent = total === 0 ? 0 : Math.round((done / total) * 100);
  return { total, done, percent };
}
