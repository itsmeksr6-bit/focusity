import type { Activity, FocusSession } from '../types';

const ACTIVITIES_KEY = 'studentos_activities';
const SESSIONS_KEY = 'studentos_focus_sessions';

export function loadActivities(): Activity[] {
  try {
    const raw = localStorage.getItem(ACTIVITIES_KEY);
    if (!raw) return getSeedData();
    return JSON.parse(raw) as Activity[];
  } catch {
    return getSeedData();
  }
}

export function saveActivities(activities: Activity[]): void {
  localStorage.setItem(ACTIVITIES_KEY, JSON.stringify(activities));
}

export function loadFocusSessions(): FocusSession[] {
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    return raw ? (JSON.parse(raw) as FocusSession[]) : [];
  } catch {
    return [];
  }
}

export function saveFocusSessions(sessions: FocusSession[]): void {
  localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
}

function getSeedData(): Activity[] {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const addHours = (d: Date, h: number) => {
    const r = new Date(d);
    r.setHours(r.getHours() + h);
    return r.toISOString();
  };

  const addDays = (d: Date, days: number) => {
    const r = new Date(d);
    r.setDate(r.getDate() + days);
    return r;
  };

  return [
    {
      id: 'seed-1',
      type: 'class',
      title: 'DBMS Lecture',
      subject: 'Database Management Systems',
      startTime: addHours(today, 9.5),
      endTime: addHours(today, 10.5),
      priority: 'medium',
      status: 'not_started',
      estimatedMinutes: 60,
      color: '#18181b',
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
    {
      id: 'seed-2',
      type: 'class',
      title: 'Java Programming Lab',
      subject: 'Object Oriented Programming',
      startTime: addHours(today, 11),
      endTime: addHours(today, 13),
      priority: 'medium',
      status: 'not_started',
      estimatedMinutes: 120,
      color: '#18181b',
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
    {
      id: 'seed-3',
      type: 'assignment',
      title: 'Java Assignment – Core Questions',
      subject: 'Java',
      deadline: addDays(today, 1).toISOString(),
      priority: 'high',
      status: 'in_progress',
      estimatedMinutes: 90,
      subtasks: [
        { id: 'st1', title: 'Read problem statement', completed: true },
        { id: 'st2', title: 'Implement core logic', completed: false },
        { id: 'st3', title: 'Write test cases', completed: false },
        { id: 'st4', title: 'Submit on portal', completed: false },
      ],
      color: '#18181b',
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
    {
      id: 'seed-4',
      type: 'exam',
      title: 'DBMS Mid-term',
      subject: 'Database Management Systems',
      deadline: addDays(today, 6).toISOString(),
      priority: 'high',
      status: 'not_started',
      estimatedMinutes: 180,
      notes: 'Focus on Joins, Normalization, Transactions',
      color: '#18181b',
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
    {
      id: 'seed-5',
      type: 'study',
      title: 'DBMS Revision – Joins & Queries',
      subject: 'DBMS',
      startTime: addHours(today, 16),
      endTime: addHours(today, 17),
      priority: 'high',
      status: 'not_started',
      estimatedMinutes: 60,
      color: '#18181b',
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
    {
      id: 'seed-6',
      type: 'personal',
      title: 'LeetCode – 1 Medium Problem',
      subject: 'Coding Practice',
      startTime: addHours(today, 18),
      endTime: addHours(today, 18.75),
      priority: 'medium',
      status: 'not_started',
      estimatedMinutes: 45,
      color: '#18181b',
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
    {
      id: 'seed-7',
      type: 'assignment',
      title: 'Lab Record – Experiment 4',
      subject: 'OS Lab',
      deadline: addDays(today, 3).toISOString(),
      priority: 'medium',
      status: 'not_started',
      estimatedMinutes: 45,
      color: '#18181b',
      createdAt: now.toISOString(),
      updatedAt: now.toISOString(),
    },
  ];
}

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}
