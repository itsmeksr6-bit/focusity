export type ActivityType =
  | 'class'
  | 'assignment'
  | 'exam'
  | 'study'
  | 'reminder'
  | 'personal';

export type Priority = 'high' | 'medium' | 'low';

export type ActivityStatus =
  | 'not_started'
  | 'in_progress'
  | 'submitted'
  | 'completed'
  | 'cancelled';

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

export interface Activity {
  id: string;
  type: ActivityType;
  title: string;
  subject?: string;
  description?: string;
  startTime?: string;
  endTime?: string;
  deadline?: string;
  priority: Priority;
  status: ActivityStatus;
  estimatedMinutes?: number;
  actualMinutes?: number;
  subtasks?: Subtask[];
  notes?: string;
  reminderEnabled?: boolean;
  isRecurring?: boolean;
  color?: string;
  createdAt: string;
  updatedAt: string;
}

export interface FocusSession {
  id: string;
  activityId: string;
  startedAt: string;
  endedAt?: string;
  durationMinutes: number;
  completed: boolean;
}

export type ViewMode = 'day' | 'week' | 'month';
