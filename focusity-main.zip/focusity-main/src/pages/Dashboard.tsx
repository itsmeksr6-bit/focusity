import PlannerApp from "@/planner/components/PlannerApp";

export default function Dashboard() {
  return <PlannerApp />;
}
