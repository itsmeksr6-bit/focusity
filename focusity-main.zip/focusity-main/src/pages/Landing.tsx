import { useEffect, useState } from 'react';
import FocusityLogo from '@/components/FocusityLogo';
import { motion } from 'framer-motion';
import { Link } from 'react-router';

const suiteTabs = [
  {
    id: 'planner',
    label: 'Planner',
    name: 'My Day',
    body: 'One quiet page for everything scheduled today — classes, deadlines and study blocks, ordered and legible.',
    icon: (
      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.75}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M8 2v4m8-4v4M3 10h18M5 4h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2V6a2 2 0 012-2z" />
      </svg>
    ),
  },
  {
    id: 'tasks',
    label: 'Tasks',
    name: 'Assignments & Exams',
    body: 'Break coursework into subtasks, track what is submitted, and see exactly what is due next.',
    icon: (
      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.75}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 11l3 3L22 4M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11" />
      </svg>
    ),
  },
  {
    id: 'focus',
    label: 'Focus',
    name: 'Focus Mode',
    body: 'Start a timer against any planned activity. When it ends, the work is marked done and the time is recorded.',
    icon: (
      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.75}>
        <circle cx="12" cy="12" r="9" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 7v5l3 2" />
      </svg>
    ),
  },
  {
    id: 'deadlines',
    label: 'Deadlines',
    name: 'Reminders',
    body: 'Overdue? Due today? Due in six days? Every deadline states itself plainly, so nothing sneaks up.',
    icon: (
      <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={1.75}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 01-3.4 0" />
      </svg>
    ),
  },
];

const subjects = ['DBMS', 'Java', 'OS Lab', 'Calculus', 'Networks', 'Statistics'];

const footerColumns = [
  {
    heading: 'Product',
    links: ['My Day', 'Assignments', 'Focus Mode', 'Reminders'],
  },
  {
    heading: 'Resources',
    links: ['Study guide', 'Changelog', 'Help center', 'Keyboard shortcuts'],
  },
  {
    heading: 'Company',
    links: ['About', 'Careers', 'Contact', 'Press'],
  },
  {
    heading: 'Legal',
    links: ['Privacy', 'Terms', 'Security'],
  },
];

function violetLink(text: string, to: string) {
  return (
    <Link
      to={to}
      className="text-[16px] font-[460] text-brand-blue transition-colors hover:underline hover:decoration-2 hover:underline-offset-2"
    >
      {text}
    </Link>
  );
}

export default function Landing() {
  const [scrolled, setScrolled] = useState(false);
  const [activeTab, setActiveTab] = useState(suiteTabs[0].id);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const active = suiteTabs.find((t) => t.id === activeTab) ?? suiteTabs[0];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className="min-h-screen bg-warm-parchment text-ink-charcoal"
    >
      {/* Announcement pill */}
      <div className="bg-brand-indigo px-4 py-3 text-center">
        <p className="text-[14px] font-[460] leading-[1.5] text-white">
          Focusity is now in open study-season preview —{' '}
          <Link to="/dashboard" className="rounded-md border border-white/60 px-2 py-0.5 text-[13px] font-[460] text-white transition-colors hover:bg-white/10">
            try the planner
          </Link>
        </p>
      </div>

      {/* Sticky nav — transparent over page, blur + hairline border on scroll */}
      <header
        className={`sticky top-0 z-40 bg-warm-parchment/70 backdrop-blur-[12px] transition-[border-color] duration-300 ${
          scrolled ? 'border-b border-soft-mist' : 'border-b border-transparent'
        }`}
      >
        <div className="mx-auto flex h-16 max-w-[1200px] items-center justify-between px-6">
          <Link to="/" className="flex items-center gap-3">
            <FocusityLogo className="text-[19px]" />
          </Link>
          <nav className="hidden items-center gap-8 md:flex">
            {suiteTabs.map((t) => (
              <a key={t.id} href="#planner" className="text-[16px] font-[460] text-ink-charcoal transition-colors hover:text-stone-gray">
                {t.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-4">
            <Link to="/auth?returnTo=%2Fdashboard" className="text-[16px] font-[460] text-ink-charcoal transition-colors hover:text-stone-gray">
              Log in
            </Link>
            <Link
              to="/auth?returnTo=%2Fdashboard"
              className="rounded-lg border border-ink-charcoal bg-brand-tint px-4 py-1.5 text-[16px] font-[460] text-ink-charcoal transition-opacity hover:opacity-90"
            >
              Sign up
            </Link>
          </div>
        </div>
      </header>

      {/* Hero — golden-hour gradient composition with floating glass product cards */}
      <section className="relative overflow-hidden">
        <div className="relative mx-auto flex min-h-[560px] max-w-[1200px] flex-col items-center justify-center px-6 py-24 text-center">
          {/* Warm sky composition */}
          <div
            aria-hidden
            className="absolute inset-0 -z-10"
            style={{
              background:
                'radial-gradient(120% 90% at 68% 50%, rgba(113,76,182,0.35) 0%, transparent 55%), radial-gradient(90% 70% at 50% 100%, rgba(226,142,84,0.45) 0%, transparent 60%), linear-gradient(178deg, #f7e3b8 0%, #eebf8a 34%, #c98a63 58%, #8a4c46 78%, #211f7c 100%)',
            }}
          />
          <p className="text-[14px] font-bold uppercase tracking-[0.14em] text-white/85">
            The student suite
          </p>
          <h1 className="mt-4 text-[49px] font-[460] leading-[1.2] tracking-[-0.027em] text-white sm:text-[64px] sm:leading-[0.96] sm:tracking-[-0.028em]">
            Every class, deadline and
            <span className="block">study session. One calm page.</span>
          </h1>
          <p className="mt-6 max-w-xl text-[16px] font-[460] leading-[1.5] text-white/90">
            Focusity turns a messy semester into a legible plan — then keeps you in
            it with a timer that actually marks the work done.
          </p>
          <div className="mt-10">
            <Link
              to="/dashboard"
              className="inline-flex h-12 items-center gap-2 rounded-2xl bg-linear-to-r from-brand-indigo to-brand-blue px-6 text-[16px] font-[460] text-white transition-opacity hover:opacity-90"
            >
              Get Focusity
              <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 12h14m-6-6l6 6-6 6" />
              </svg>
            </Link>
          </div>

          {/* Floating translucent product cards */}
          <div className="pointer-events-none absolute left-6 top-1/2 hidden w-56 -translate-y-6 rounded-2xl border border-white/20 bg-white/85 p-4 backdrop-blur-[6px] lg:block">
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-brand-blue" />
              <p className="text-[13px] font-bold text-ink-charcoal">Focus Mode</p>
            </div>
            <p className="mt-2 font-mono text-2xl text-ink-charcoal tabular-nums">25:00</p>
            <p className="mt-1 text-[13px] font-[460] text-stone-gray">
              DBMS Revision — Joins &amp; Queries
            </p>
            <p className="mt-3 text-[13px] font-[460] text-brand-blue">Start session →</p>
          </div>
          <div className="pointer-events-none absolute right-6 top-1/2 hidden w-56 translate-y-10 rounded-2xl border border-white/20 bg-white/85 p-4 backdrop-blur-[6px] lg:block">
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-brand-tint" />
              <p className="text-[13px] font-bold text-ink-charcoal">Java Assignment</p>
            </div>
            <p className="mt-2 text-[13px] font-[460] leading-[1.5] text-stone-gray">
              Due tomorrow · 2 of 4 subtasks done
            </p>
            <p className="mt-3 text-[13px] font-[460] text-brand-blue">Open planner →</p>
          </div>
        </div>
      </section>

      {/* Trust strip — square white cells */}
      <section className="border-y border-soft-mist bg-paper-white">
        <div className="mx-auto grid max-w-[1200px] grid-cols-3 md:grid-cols-6">
          {subjects.map((s) => (
            <div key={s} className="flex items-center justify-center border-soft-mist py-8 [&:not(:last-child)]:border-r">
              <span className="text-[16px] font-[460] text-ink-charcoal">{s}</span>
            </div>
          ))}
        </div>
      </section>

      {/* Suite tabs + product card */}
      <section id="planner" className="mx-auto max-w-[1200px] px-6 py-24">
        <h2 className="text-[48px] font-[460] leading-[0.96] text-ink-charcoal">
          Your Focusity suite
        </h2>
        <div className="mt-10 overflow-hidden rounded-lg border border-soft-mist bg-paper-white">
          <div className="grid grid-cols-4">
            {suiteTabs.map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                className={`flex items-center justify-center gap-2.5 p-4 text-[16px] font-[460] transition-colors ${
                  activeTab === t.id
                    ? 'bg-brand-tint text-ink-charcoal'
                    : 'bg-paper-white text-ink-charcoal hover:bg-warm-parchment'
                }`}
              >
                <span className={activeTab === t.id ? 'text-brand-indigo' : 'text-stone-gray'}>
                  {t.icon}
                </span>
                {t.label}
              </button>
            ))}
          </div>
        </div>
        <div className="mt-6 rounded-2xl border border-soft-mist bg-paper-white p-6">
          <span className="text-brand-blue">{active.icon}</span>
          <h3 className="mt-4 text-[19px] font-bold text-ink-charcoal">{active.name}</h3>
          <p className="mt-1 max-w-xl text-[16px] font-[460] leading-[1.5] text-ink-charcoal">
            {active.body}
          </p>
          <div className="mt-3">{violetLink('Learn more', '/dashboard')}</div>
        </div>
      </section>

      {/* Dark feature band — the only full-bleed dark surface */}
      <section className="bg-brand-night">
        <div className="mx-auto grid max-w-[1200px] items-center gap-16 px-6 py-24 lg:grid-cols-2">
          <div className="relative flex h-80 items-center justify-center">
            <div aria-hidden className="absolute h-56 w-56 rounded-2xl bg-brand-tint/50 rotate-[-8deg]" />
            <div aria-hidden className="absolute h-56 w-56 rounded-2xl bg-[#7ba7d9]/40 rotate-[6deg] translate-x-10" />
            <div aria-hidden className="absolute h-56 w-56 rounded-2xl bg-[#e6a4c4]/40 rotate-[16deg] translate-x-4 -translate-y-3" />
            <p
              aria-hidden
              className="relative z-10 -rotate-6 text-4xl italic text-white/90"
              style={{ fontFamily: 'Snell Roundhand, Segoe Script, cursive' }}
            >
              plan less, do more
            </p>
          </div>
          <div>
            <h2 className="text-[49px] font-[460] leading-[1.2] tracking-[-0.027em] text-white">
              The quietest way to run a semester
            </h2>
            <p className="mt-6 max-w-md text-[16px] font-[460] leading-[1.5] text-white/90">
              No pings, no confetti, no dashboards screaming for attention. Focusity
              states the work plainly, then steps out of the way while you do it.
            </p>
            <Link
              to="/dashboard"
              className="mt-8 inline-block rounded-lg border border-white px-5 py-2 text-[16px] font-[460] text-white transition-colors hover:bg-white/10"
            >
              Read our announcement
            </Link>
          </div>
        </div>
      </section>

      {/* Gradient atmospheric band */}
      <section className="relative overflow-hidden border-y border-soft-mist">
        <div
          aria-hidden
          className="absolute inset-0"
          style={{
            background:
              'radial-gradient(45% 60% at 68% 50%, rgba(113,76,182,0.5) 0%, transparent 100%), radial-gradient(40% 55% at 93% 50%, rgba(123,167,217,0.5) 0%, transparent 100%), radial-gradient(45% 55% at 50% 98%, rgba(230,164,196,0.55) 0%, transparent 100%), radial-gradient(40% 55% at 50% 75%, rgba(120,200,205,0.5) 0%, transparent 100%)',
          }}
        />
        <div className="relative mx-auto flex max-w-[1200px] flex-wrap items-center justify-between gap-8 px-6 py-20">
          <h2 className="text-[48px] font-[460] leading-[0.96] text-ink-charcoal">
            Stay ahead, stay effortless
          </h2>
          <Link
            to="/dashboard"
            className="h-12 rounded-2xl bg-paper-white px-6 text-[16px] font-[460] text-ink-charcoal inline-flex items-center transition-opacity hover:opacity-90"
          >
            Get Focusity
          </Link>
        </div>
      </section>

      {/* Footer — wine ground */}
      <footer className="bg-brand-night">
        <div className="mx-auto max-w-[1200px] px-6 pb-24 pt-16">
          <div className="flex items-center gap-3">
            <FocusityLogo className="text-[19px]" onDark />
          </div>
          <div className="mt-12 grid grid-cols-2 gap-12 md:grid-cols-4">
            {footerColumns.map((col) => (
              <div key={col.heading}>
                <h4 className="text-[14px] font-bold text-white">{col.heading}</h4>
                <ul className="mt-4 space-y-3">
                  {col.links.map((l) => (
                    <li key={l}>
                      <Link
                        to="/dashboard"
                        className="text-[14px] font-[460] text-white/85 transition-colors hover:text-white"
                      >
                        {l}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </footer>
    </motion.div>
  );
}
